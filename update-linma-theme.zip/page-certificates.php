<?php
/* Template Name: Дилерские сертификаты — Linma Electronics */
global $linma_meta;
$linma_meta = array(
  'title'          => 'Дилерские сертификаты — Linma Electronics',
  'description'    => 'Дилерские и дистрибьюторские сертификаты Linma Electronics: Daikin, Kentatsu, Midea, VENTZ, NED, Energolux, FeRRUM, KALASHNIKOV, LuftMeer, WHEIL, Тепломаш, СовПлим и другие производители.',
  'canonical'      => 'certificates/',
  'og_title'       => 'Дилерские сертификаты — Linma Electronics',
  'og_description' => 'Дилерские и дистрибьюторские сертификаты Linma Electronics: Daikin, Kentatsu, Midea, VENTZ, NED, Energolux, FeRRUM, KALASHNIKOV, LuftMeer, WHEIL, Тепломаш, СовПлим и другие производители.',
  'body_page'      => 'certificates',
);
get_header();
?>
<main id="main">
  <section class="page-hero">
    <div class="container">
      <nav class="breadcrumbs" aria-label="Хлебные крошки">
        <ol>
          <li><a href="/">Главная</a></li>
          <li>Сертификаты</li>
        </ol>
      </nav>

      <p class="eyebrow" data-reveal>Подтверждение статуса</p>
      <h1 data-reveal="60">Дилерские сертификаты</h1>
      <p class="lead" data-reveal="120">
        Нажмите на документ, чтобы рассмотреть его целиком или скачать PDF.
      </p>
    </div>
  </section>

  <section class="section section--tight">
    <div class="container">
      <?php
      // Плитки собираются здесь, на сервере, а не скриптом в браузере:
      // так сертификаты попадают в исходный код страницы и их видят
      // поисковики. Скрипту тот же список отдаётся ниже — на нём
      // держится окно просмотра.
      $linma_certs = linma_cert_items();
      ?>

      <div class="cert-grid" data-cert-grid data-reveal>
        <?php linma_cert_cards( $linma_certs, false ); ?>
      </div>

      <!-- Документы альбомной ориентации: своя сетка с горизонтальными
           рамками, иначе они болтались бы в вертикальных плитках -->
      <div class="cert-grid cert-grid--wide" data-cert-grid-wide data-reveal>
        <?php linma_cert_cards( $linma_certs, true ); ?>
      </div>

      <?php linma_cert_inline_data( $linma_certs ); ?>

      <p class="text-muted mt-lg" style="font-size:.86rem;">
        Сертификаты выданы на ООО «ЛИНМА». Если по вашему проекту нужен документ
        от конкретного производителя, которого нет в списке, — напишите нам,
        мы подтвердим статус отдельным письмом.
      </p>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="cta-band" data-reveal>
        <div class="inner">
          <div>
            <h2>Нужен документ по вашему проекту?</h2>
            <p>Подтвердим статус официального поставщика по нужной марке и приложим сертификат к коммерческому предложению.</p>
          </div>
          <a class="btn btn--lg" href="/contacts/#request">Оставить заявку <span class="arrow">↗</span></a>
        </div>
      </div>
    </div>
  </section>

  <!-- Просмотр сертификата -->
  <div class="lightbox" data-lightbox hidden role="dialog" aria-modal="true" aria-label="Просмотр сертификата">
    <div class="lightbox-bar">
      <span class="lightbox-title" data-lightbox-title></span>
      <span class="spacer"></span>
      <a class="btn btn--ghost" data-lightbox-pdf href="#" target="_blank" rel="noopener" download>Скачать PDF</a>
      <button class="slider-btn" type="button" data-lightbox-close aria-label="Закрыть просмотр">
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true"><path d="m4 4 10 10M14 4 4 14" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
      </button>
    </div>

    <div class="lightbox-stage">
      <!-- src подставляется скриптом при открытии: пустой src=""
           заставляет браузер запрашивать саму страницу как картинку -->
      <img data-lightbox-img alt="">
    </div>

    <div class="lightbox-nav">
      <button class="slider-btn" type="button" data-lightbox-prev aria-label="Предыдущий сертификат">
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true"><path d="M11 3 5 9l6 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      <span class="lightbox-counter" data-lightbox-counter></span>
      <button class="slider-btn" type="button" data-lightbox-next aria-label="Следующий сертификат">
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true"><path d="m7 3 6 6-6 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
    </div>
  </div>

</main>
<?php get_footer(); ?>
