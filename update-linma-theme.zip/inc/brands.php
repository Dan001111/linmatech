<?php
/**
 * Раздел «Бренды» в админке.
 *
 * Логотипы партнёров раньше жили в assets/js/brands.js, а файлы —
 * в assets/img/brands/. Здесь это обычные записи: загрузили логотип,
 * отметили направления, опубликовали.
 *
 * Бренды выводятся в трёх местах сразу: бегущая строка на главной,
 * сетка с фильтром на странице «Бренды-партнёры» и блок «Бренды
 * направления» на страницах оборудования. Все три собираются одним
 * и тем же кодом в main.js — меняется только список, который сюда
 * приходит.
 *
 * Что важно знать при правках:
 *   - Заголовок записи — название бренда. Оно же подпись к логотипу.
 *   - Логотип прикладывается как изображение записи.
 *   - Направления — галочки. Можно несколько: бренд попадёт в каждое.
 *   - Порядок задаётся полем «Порядок» в блоке «Свойства записи».
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Направления поставки. Те же четыре раздела, что и в меню сайта,
 * поэтому список задан здесь, а не редактируется из админки.
 */
function linma_brand_groups() {
	return array(
		'ventilation'  => 'Вентиляция',
		'conditioning' => 'Кондиционирование',
		'heating'      => 'Отопление',
		'smoke'        => 'Дымоудаление',
	);
}

/**
 * ===================================================================
 *  ТИП ЗАПИСИ
 * ===================================================================
 */

function linma_brand_register() {
	register_post_type( 'linma_brand', array(
		'labels' => array(
			'name'                  => 'Бренды',
			'singular_name'         => 'Бренд',
			'menu_name'             => 'Бренды',
			'add_new'               => 'Добавить',
			'add_new_item'          => 'Новый бренд',
			'edit_item'             => 'Редактирование бренда',
			'new_item'              => 'Новый бренд',
			'search_items'          => 'Искать бренды',
			'not_found'             => 'Брендов пока нет',
			'not_found_in_trash'    => 'В корзине пусто',
			'featured_image'        => 'Логотип',
			'set_featured_image'    => 'Загрузить логотип',
			'remove_featured_image' => 'Убрать логотип',
			'use_featured_image'    => 'Использовать как логотип',
		),
		// Отдельных страниц у брендов нет — они показываются плитками.
		'public'             => false,
		'publicly_queryable' => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_position'      => 22,
		'menu_icon'          => 'dashicons-tag',
		'supports'           => array( 'title', 'thumbnail', 'page-attributes' ),
		'has_archive'        => false,
		'rewrite'            => false,
		'can_export'         => true,
	) );

	// Логотипы приводились к 360x140 — плитки одинаковые независимо от
	// того, широкий логотип или квадратный. Обрезки нет: картинка
	// вписывается в эти габариты целиком.
	add_image_size( 'linma-brand', 360, 140, false );
}
add_action( 'init', 'linma_brand_register' );

function linma_brand_title_placeholder( $text, $post ) {
	if ( $post && 'linma_brand' === $post->post_type ) {
		return 'Название бренда — например, Daikin';
	}
	return $text;
}
add_filter( 'enter_title_here', 'linma_brand_title_placeholder', 10, 2 );

/**
 * ===================================================================
 *  ПОЛЯ
 * ===================================================================
 */

function linma_brand_meta_box() {
	add_meta_box(
		'linma-brand-fields',
		'Данные бренда',
		'linma_brand_meta_box_html',
		'linma_brand',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'linma_brand_meta_box' );

function linma_brand_meta_box_html( $post ) {
	wp_nonce_field( 'linma_brand_save', 'linma_brand_nonce' );

	$chosen = get_post_meta( $post->ID, '_linma_groups', true );
	if ( ! is_array( $chosen ) ) {
		$chosen = array();
	}
	$url = get_post_meta( $post->ID, '_linma_url', true );
	?>
	<style>
		.linma-fields { display: grid; gap: 1.2rem; max-width: 720px; margin: .6rem 0; }
		.linma-fields > div > label:first-child { display: block; font-weight: 600; margin-bottom: .4rem; }
		.linma-fields input[type="url"] { width: 100%; }
		.linma-fields .hint { margin: .35rem 0 0; color: #646970; font-size: 12px; }
		.linma-groups { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: .4rem .8rem; }
		.linma-groups label { font-weight: 400; }
	</style>

	<div class="linma-fields">

		<div>
			<label>Направления поставки</label>
			<div class="linma-groups">
				<?php foreach ( linma_brand_groups() as $id => $label ) : ?>
					<label>
						<input type="checkbox" name="linma_groups[]" value="<?php echo esc_attr( $id ); ?>"
							<?php checked( in_array( $id, $chosen, true ) ); ?>>
						<?php echo esc_html( $label ); ?>
					</label>
				<?php endforeach; ?>
			</div>
			<p class="hint">Определяют, на каких страницах оборудования показывать бренд
				и под какой фильтр он попадёт на странице «Бренды-партнёры».
				Можно отметить несколько. Если не отмечено ни одного, бренд
				останется только в бегущей строке на главной.</p>
		</div>

		<div>
			<label for="linma-url">Сайт производителя</label>
			<input type="url" id="linma-url" name="linma_url"
			       value="<?php echo esc_attr( $url ); ?>"
			       placeholder="https://example.com">
			<p class="hint">Необязательно. Если указан, плитка станет ссылкой
				и будет открываться в новой вкладке.</p>
		</div>

	</div>
	<?php
}

function linma_brand_save( $post_id ) {
	if ( ! isset( $_POST['linma_brand_nonce'] )
		|| ! wp_verify_nonce( sanitize_key( $_POST['linma_brand_nonce'] ), 'linma_brand_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	// Принимаем только те направления, которые реально существуют, —
	// иначе опечатка в запросе попала бы в данные сайта.
	$allowed = array_keys( linma_brand_groups() );
	$groups  = array();
	if ( isset( $_POST['linma_groups'] ) && is_array( $_POST['linma_groups'] ) ) {
		foreach ( wp_unslash( $_POST['linma_groups'] ) as $g ) {
			$g = sanitize_key( $g );
			if ( in_array( $g, $allowed, true ) ) {
				$groups[] = $g;
			}
		}
	}
	update_post_meta( $post_id, '_linma_groups', $groups );

	$url = isset( $_POST['linma_url'] ) ? esc_url_raw( wp_unslash( $_POST['linma_url'] ) ) : '';
	update_post_meta( $post_id, '_linma_url', $url );
}
add_action( 'save_post_linma_brand', 'linma_brand_save' );

/**
 * ===================================================================
 *  СПИСОК В АДМИНКЕ
 * ===================================================================
 */

function linma_brand_columns( $cols ) {
	return array(
		'cb'           => isset( $cols['cb'] ) ? $cols['cb'] : '',
		'linma_logo'   => 'Логотип',
		'title'        => 'Название',
		'linma_groups' => 'Направления',
		'linma_url'    => 'Сайт',
		'menu_order'   => 'Порядок',
	);
}
add_filter( 'manage_linma_brand_posts_columns', 'linma_brand_columns' );

function linma_brand_column( $col, $post_id ) {
	switch ( $col ) {
		case 'linma_logo':
			if ( has_post_thumbnail( $post_id ) ) {
				// Логотипы светлые, на белом фоне админки их не видно —
				// показываем на тёмной подложке, как на сайте.
				echo '<span style="display:inline-block;padding:6px 10px;background:#0E2426;border-radius:4px">';
				echo get_the_post_thumbnail( $post_id, 'linma-brand', array( 'style' => 'width:auto;height:26px;display:block' ) );
				echo '</span>';
			} else {
				echo '<span style="color:#d63638">нет логотипа</span>';
			}
			break;

		case 'linma_groups':
			$groups = get_post_meta( $post_id, '_linma_groups', true );
			$all    = linma_brand_groups();
			if ( ! is_array( $groups ) || ! $groups ) {
				echo '<span style="color:#646970">не отмечены</span>';
				break;
			}
			$names = array();
			foreach ( $groups as $g ) {
				if ( isset( $all[ $g ] ) ) {
					$names[] = $all[ $g ];
				}
			}
			echo esc_html( implode( ', ', $names ) );
			break;

		case 'linma_url':
			$url = get_post_meta( $post_id, '_linma_url', true );
			if ( $url ) {
				echo '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">'
					. esc_html( wp_parse_url( $url, PHP_URL_HOST ) ) . '</a>';
			} else {
				echo '<span style="color:#646970">—</span>';
			}
			break;

		case 'menu_order':
			echo (int) get_post_field( 'menu_order', $post_id );
			break;
	}
}
add_action( 'manage_linma_brand_posts_custom_column', 'linma_brand_column', 10, 2 );

function linma_brand_sortable( $cols ) {
	$cols['menu_order'] = 'menu_order';
	return $cols;
}
add_filter( 'manage_edit-linma_brand_sortable_columns', 'linma_brand_sortable' );

/**
 * Список в админке должен идти в том же порядке, что и на сайте.
 */
function linma_brand_admin_order( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( 'linma_brand' !== $query->get( 'post_type' ) ) {
		return;
	}
	if ( ! $query->get( 'orderby' ) ) {
		$query->set( 'orderby', 'menu_order title' );
		$query->set( 'order', 'ASC' );
	}
}
add_action( 'pre_get_posts', 'linma_brand_admin_order' );

/**
 * ===================================================================
 *  ДАННЫЕ ДЛЯ САЙТА
 * ===================================================================
 */

/**
 * Собирает бренды в том же виде, в каком их раньше отдавал brands.js.
 * Поле logo — готовый адрес файла в медиатеке: по имени его не собрать,
 * WordPress хранит загруженные картинки по своим правилам.
 */
function linma_brand_items() {
	$posts = get_posts( array(
		'post_type'   => 'linma_brand',
		'post_status' => 'publish',
		'numberposts' => -1,
		'orderby'     => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
	) );

	$items = array();

	foreach ( $posts as $post ) {
		$logo_id = get_post_thumbnail_id( $post->ID );
		$groups  = get_post_meta( $post->ID, '_linma_groups', true );

		$items[] = array(
			'name'   => $post->post_title,
			'logo'   => $logo_id ? wp_get_attachment_image_url( $logo_id, 'linma-brand' ) : '',
			'groups' => is_array( $groups ) ? array_values( $groups ) : array(),
			'url'    => (string) get_post_meta( $post->ID, '_linma_url', true ),
		);
	}

	return $items;
}

/**
 * Печатает списки для скрипта. Нужны почти на всех страницах: бегущая
 * строка идёт на главной, блок «Бренды направления» — на страницах
 * оборудования, сетка с фильтром — на странице брендов.
 */
function linma_brand_inline_data() {
	$groups = array();
	foreach ( linma_brand_groups() as $id => $label ) {
		$groups[] = array( 'id' => $id, 'label' => $label );
	}

	$flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;

	echo '<script>'
		. 'window.LINMA_BRANDS = ' . wp_json_encode( linma_brand_items(), $flags ) . ';'
		. 'window.LINMA_BRAND_GROUPS = ' . wp_json_encode( $groups, $flags ) . ';'
		. '</script>' . "\n";
}
