<?php
/**
 * Разовый перенос сертификатов из файлов темы в админку.
 *
 * До перехода на записи сертификаты описывались в assets/js/certificates.js,
 * а сканы и документы лежали в assets/img/certificates/ и
 * assets/docs/certificates/. Этот файл создаёт из них записи и переносит
 * файлы в медиатеку, чтобы не заполнять семнадцать карточек руками.
 *
 * Запускается кнопкой один раз. Повторный запуск ничего не сломает:
 * записи, которые уже созданы, пропускаются.
 *
 * После переноса файл можно удалить вместе с исходными картинками
 * в теме — но лучше не торопиться и оставить до переезда на боевой домен.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Описания сертификатов на момент перехода. Порядок тот же, что был
 * на странице.
 */
function linma_cert_seed() {
	return array(
		array(
			'slug'   => 'daikin',
			'brand'  => 'Daikin',
			'issuer' => 'ООО «Даичи», генеральный дистрибьютор',
			'type'   => 'Авторизованный дилер',
			'valid'  => 'до 31 декабря 2026',
			'ends'   => '2026-12-31',
			'wide'   => false,
		),
		array(
			'slug'   => 'kentatsu',
			'brand'  => 'Kentatsu',
			'issuer' => 'ООО «Даичи», генеральный дистрибьютор',
			'type'   => 'Авторизованный дилер',
			'valid'  => 'до 31 декабря 2026',
			'ends'   => '2026-12-31',
			'wide'   => true,
		),
		array(
			'slug'   => 'midea',
			'brand'  => 'Midea',
			'issuer' => 'ООО «Даичи», генеральный дистрибьютор',
			'type'   => 'Авторизованный дилер',
			'valid'  => 'до 31 декабря 2026',
			'ends'   => '2026-12-31',
			'wide'   => true,
		),
		array(
			'slug'   => 'ventz',
			'brand'  => 'VENTZ',
			'issuer' => 'ООО «Торговый дом ВЕНТЗ»',
			'type'   => 'Официальный дилер',
			'valid'  => 'до 1 июня 2027',
			'ends'   => '2027-06-01',
			'wide'   => false,
		),
		array(
			'slug'   => 'ned',
			'brand'  => 'NED',
			'issuer' => 'ООО «НЕД-Инжиниринг»',
			'type'   => 'Официальный партнёр',
			'valid'  => 'до 31 декабря 2027',
			'ends'   => '2027-12-31',
			'wide'   => false,
		),
		array(
			'slug'   => 'normalvent',
			'brand'  => 'LuftMeer, Заслон',
			'issuer' => 'ГК «Нормал Вент»',
			'type'   => 'Официальный дистрибьютор',
			'valid'  => 'до 31 декабря 2028',
			'ends'   => '2028-12-31',
			'wide'   => true,
		),
		array(
			'slug'   => 'wheil',
			'brand'  => 'WHEIL, Lite One',
			'issuer' => 'ООО «НПТ Климатика»',
			'type'   => 'Официальный партнёр',
			'valid'  => 'до 1 июля 2027',
			'ends'   => '2027-07-01',
			'wide'   => false,
		),
		array(
			'slug'   => 'energolux',
			'brand'  => 'Energolux',
			'issuer' => 'ООО «Северкон»',
			'type'   => 'Партнёр для объектных продаж',
			'valid'  => 'до 31 декабря 2026',
			'ends'   => '2026-12-31',
			'wide'   => false,
		),
		array(
			'slug'   => 'ferrum',
			'brand'  => 'FeRRUM',
			'issuer' => 'ООО «Северкон»',
			'type'   => 'Партнёр для объектных продаж',
			'valid'  => 'до 31 декабря 2026',
			'ends'   => '2026-12-31',
			'wide'   => false,
		),
		array(
			'slug'   => 'kalashnikov',
			'brand'  => 'KALASHNIKOV',
			'issuer' => 'ООО «Северкон»',
			'type'   => 'Партнёр для объектных продаж',
			'valid'  => 'до 31 декабря 2026',
			'ends'   => '2026-12-31',
			'wide'   => false,
		),
		array(
			'slug'   => 'aerogo',
			'brand'  => 'Aerostar',
			'issuer' => 'ООО «Аэро Групп»',
			'type'   => 'Официальный дилер',
			'valid'  => 'выдан 14 июля 2026',
			'ends'   => '',
			'wide'   => true,
		),
		array(
			'slug'   => 'vega',
			'brand'  => 'VEGA-AIR',
			'issuer' => 'ООО «Вега»',
			'type'   => 'Официальный дилер',
			'valid'  => 'до 31 декабря 2026',
			'ends'   => '2026-12-31',
			'wide'   => true,
		),
		array(
			'slug'   => 'greers',
			'brand'  => 'ГРЕЕРС',
			'issuer' => 'ООО «ЮНИО-ВЕНТ»',
			'type'   => 'Официальный партнёр',
			'valid'  => 'до 1 декабря 2026',
			'ends'   => '2026-12-01',
			'wide'   => false,
		),
		array(
			'slug'   => 'innovent',
			'brand'  => 'ИННОВЕНТ',
			'issuer' => 'ООО «Инновент»',
			'type'   => 'Официальный дилер',
			'valid'  => 'до 31 декабря 2027',
			'ends'   => '2027-12-31',
			'wide'   => false,
		),
		array(
			'slug'   => 'sovplim',
			'brand'  => 'СовПлим',
			'issuer' => 'АО «СовПлим»',
			'type'   => 'Партнёрская компания',
			'valid'  => 'выдан 1 июня 2026',
			'ends'   => '',
			'wide'   => false,
		),
		array(
			'slug'   => 'teplomash',
			'brand'  => 'Тепломаш',
			'issuer' => 'АО «НПО «Тепломаш»',
			'type'   => 'Авторизованный дилер',
			'valid'  => 'выдан 14 июля 2026',
			'ends'   => '',
			'wide'   => false,
		),
		array(
			'slug'   => 'yalka',
			'brand'  => 'ЯЛКА',
			'issuer' => 'ООО «ЯЛКА»',
			'type'   => 'Официальный дилер',
			'valid'  => 'до 31 декабря 2027',
			'ends'   => '2027-12-31',
			'wide'   => false,
		),
	);
}

function linma_cert_import_menu() {
	add_submenu_page(
		'edit.php?post_type=linma_cert',
		'Перенести из файлов темы',
		'Перенести из файлов',
		'manage_options',
		'linma-cert-import',
		'linma_cert_import_page'
	);
}
add_action( 'admin_menu', 'linma_cert_import_menu' );

function linma_cert_import_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Недостаточно прав.' );
	}

	$done = false;
	$log  = array();

	if ( isset( $_POST['linma_cert_import'] )
		&& check_admin_referer( 'linma_cert_import' ) ) {
		$log  = linma_cert_run_import();
		$done = true;
	}

	$existing = (int) wp_count_posts( 'linma_cert' )->publish;
	?>
	<div class="wrap">
		<h1>Перенести сертификаты из файлов темы</h1>

		<?php if ( $done ) : ?>
			<div class="notice notice-success"><p><strong>Перенос выполнен.</strong></p></div>
			<table class="widefat striped" style="max-width:760px">
				<thead><tr><th>Сертификат</th><th>Что сделано</th></tr></thead>
				<tbody>
				<?php foreach ( $log as $row ) : ?>
					<tr>
						<td><?php echo esc_html( $row['brand'] ); ?></td>
						<td><?php echo esc_html( $row['status'] ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p><a class="button button-primary" href="<?php echo esc_url( admin_url( 'edit.php?post_type=linma_cert' ) ); ?>">Открыть список сертификатов</a></p>

		<?php else : ?>
			<p style="max-width:640px">
				Создаст записи по описаниям из файла темы и перенесёт сканы и
				документы в медиатеку. Заполнять карточки вручную не придётся.
			</p>
			<p style="max-width:640px">
				Сертификатов в базе сейчас: <strong><?php echo (int) $existing; ?></strong>.
				Те, что уже созданы, будут пропущены — запускать можно спокойно.
			</p>
			<form method="post">
				<?php wp_nonce_field( 'linma_cert_import' ); ?>
				<p>
					<button type="submit" name="linma_cert_import" value="1" class="button button-primary">
						Перенести <?php echo count( linma_cert_seed() ); ?> сертификатов
					</button>
				</p>
			</form>
		<?php endif; ?>
	</div>
	<?php
}

function linma_cert_run_import() {
	$log   = array();
	$order = 0;

	foreach ( linma_cert_seed() as $c ) {
		$order += 10;

		$exists = get_posts( array(
			'post_type'   => 'linma_cert',
			'name'        => $c['slug'],
			'post_status' => 'any',
			'numberposts' => 1,
		) );

		if ( $exists ) {
			$log[] = array( 'brand' => $c['brand'], 'status' => 'уже был — пропущен' );
			continue;
		}

		$post_id = wp_insert_post( array(
			'post_type'   => 'linma_cert',
			'post_status' => 'publish',
			'post_title'  => $c['brand'],
			'post_name'   => $c['slug'],
			'menu_order'  => $order,
		), true );

		if ( is_wp_error( $post_id ) ) {
			$log[] = array( 'brand' => $c['brand'], 'status' => 'не удалось создать запись' );
			continue;
		}

		update_post_meta( $post_id, '_linma_issuer', $c['issuer'] );
		update_post_meta( $post_id, '_linma_type', $c['type'] );
		update_post_meta( $post_id, '_linma_valid', $c['valid'] );
		update_post_meta( $post_id, '_linma_ends', $c['ends'] );
		update_post_meta( $post_id, '_linma_wide', $c['wide'] ? '1' : '' );

		$notes = array();

		// Скан берём крупный — WordPress сам нарежет из него плитку.
		$img_id = linma_sideload_theme_file( 'assets/img/certificates/' . $c['slug'] . '.jpg' );
		if ( $img_id ) {
			set_post_thumbnail( $post_id, $img_id );
		} else {
			$notes[] = 'скан не найден';
		}

		$pdf_id = linma_sideload_theme_file( 'assets/docs/certificates/' . $c['slug'] . '.pdf' );
		if ( $pdf_id ) {
			update_post_meta( $post_id, '_linma_pdf', $pdf_id );
		} else {
			$notes[] = 'PDF не найден';
		}

		$log[] = array(
			'brand'  => $c['brand'],
			'status' => $notes ? 'создан, но ' . implode( ', ', $notes ) : 'создан со сканом и PDF',
		);
	}

	return $log;
}
