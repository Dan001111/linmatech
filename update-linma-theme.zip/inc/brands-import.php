<?php
/**
 * Разовый перенос брендов из файлов темы в админку.
 *
 * Описания брали из assets/js/brands.js, логотипы — из
 * assets/img/brands/. Этот файл создаёт записи и переносит логотипы
 * в медиатеку, чтобы не заполнять два десятка карточек руками.
 *
 * Запускается кнопкой один раз. Повторный запуск безопасен: бренды,
 * которые уже созданы, пропускаются — сверка идёт по названию.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Бренды на момент перехода. Порядок тот же, что был на сайте.
 */
function linma_brand_seed() {
	return array(
		array(
			'name'   => 'Daikin',
			'file'   => 'daikin.png',
			'groups' => array('conditioning'),
			'url'    => '',
		),
		array(
			'name'   => 'Midea',
			'file'   => 'midea.png',
			'groups' => array('conditioning'),
			'url'    => '',
		),
		array(
			'name'   => 'Kentatsu',
			'file'   => 'kentatsu.png',
			'groups' => array('conditioning'),
			'url'    => '',
		),
		array(
			'name'   => 'Даичи',
			'file'   => 'daichi.png',
			'groups' => array('conditioning'),
			'url'    => '',
		),
		array(
			'name'   => 'Energolux',
			'file'   => 'energolux.png',
			'groups' => array('conditioning'),
			'url'    => '',
		),
		array(
			'name'   => 'FeRRUM',
			'file'   => 'ferrum.png',
			'groups' => array('conditioning'),
			'url'    => '',
		),
		array(
			'name'   => 'HTS',
			'file'   => 'hts.png',
			'groups' => array('conditioning'),
			'url'    => '',
		),
		array(
			'name'   => 'Refcool',
			'file'   => 'refcool.png',
			'groups' => array('conditioning'),
			'url'    => '',
		),
		array(
			'name'   => 'VENTZ',
			'file'   => 'ventz.png',
			'groups' => array('ventilation', 'smoke'),
			'url'    => '',
		),
		array(
			'name'   => 'NED',
			'file'   => 'ned.png',
			'groups' => array('ventilation', 'smoke'),
			'url'    => '',
		),
		array(
			'name'   => 'WHEIL',
			'file'   => 'wheil.png',
			'groups' => array('ventilation', 'smoke'),
			'url'    => '',
		),
		array(
			'name'   => 'Аэро Групп',
			'file'   => 'aerogroup.png',
			'groups' => array('ventilation'),
			'url'    => '',
		),
		array(
			'name'   => 'Вега',
			'file'   => 'vega.png',
			'groups' => array('ventilation'),
			'url'    => '',
		),
		array(
			'name'   => 'Инновент',
			'file'   => 'innovent.png',
			'groups' => array('ventilation', 'smoke'),
			'url'    => '',
		),
		array(
			'name'   => 'Нормал Вент',
			'file'   => 'normalvent.png',
			'groups' => array('ventilation', 'smoke'),
			'url'    => '',
		),
		array(
			'name'   => 'СовПлим',
			'file'   => 'sovplim.png',
			'groups' => array('ventilation'),
			'url'    => '',
		),
		array(
			'name'   => 'ЯЛКА',
			'file'   => 'yalka.png',
			'groups' => array('ventilation'),
			'url'    => '',
		),
		array(
			'name'   => 'Тепломаш',
			'file'   => 'teplomash.png',
			'groups' => array('heating'),
			'url'    => '',
		),
		array(
			'name'   => 'KALASHNIKOV',
			'file'   => 'kalashnikov.png',
			'groups' => array('heating'),
			'url'    => '',
		),
		array(
			'name'   => 'ГРЕЕРС',
			'file'   => 'greers.png',
			'groups' => array('heating'),
			'url'    => '',
		),
		array(
			'name'   => 'ПК Технология',
			'file'   => 'pk-tech.png',
			'groups' => array('heating'),
			'url'    => '',
		),
	);
}

function linma_brand_import_menu() {
	add_submenu_page(
		'edit.php?post_type=linma_brand',
		'Перенести из файлов темы',
		'Перенести из файлов',
		'manage_options',
		'linma-brand-import',
		'linma_brand_import_page'
	);
}
add_action( 'admin_menu', 'linma_brand_import_menu' );

function linma_brand_import_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Недостаточно прав.' );
	}

	$done = false;
	$log  = array();

	if ( isset( $_POST['linma_brand_import'] )
		&& check_admin_referer( 'linma_brand_import' ) ) {
		$log  = linma_brand_run_import();
		$done = true;
	}

	$existing = (int) wp_count_posts( 'linma_brand' )->publish;
	?>
	<div class="wrap">
		<h1>Перенести бренды из файлов темы</h1>

		<?php if ( $done ) : ?>
			<div class="notice notice-success"><p><strong>Перенос выполнен.</strong></p></div>
			<table class="widefat striped" style="max-width:760px">
				<thead><tr><th>Бренд</th><th>Что сделано</th></tr></thead>
				<tbody>
				<?php foreach ( $log as $row ) : ?>
					<tr>
						<td><?php echo esc_html( $row['name'] ); ?></td>
						<td><?php echo esc_html( $row['status'] ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p><a class="button button-primary" href="<?php echo esc_url( admin_url( 'edit.php?post_type=linma_brand' ) ); ?>">Открыть список брендов</a></p>

		<?php else : ?>
			<p style="max-width:640px">
				Создаст записи по описаниям из файла темы и перенесёт логотипы
				в медиатеку. Заполнять карточки вручную не придётся.
			</p>
			<p style="max-width:640px">
				Брендов в базе сейчас: <strong><?php echo (int) $existing; ?></strong>.
				Те, что уже созданы, будут пропущены — сверка идёт по названию.
			</p>
			<form method="post">
				<?php wp_nonce_field( 'linma_brand_import' ); ?>
				<p>
					<button type="submit" name="linma_brand_import" value="1" class="button button-primary">
						Перенести <?php echo count( linma_brand_seed() ); ?> брендов
					</button>
				</p>
			</form>
		<?php endif; ?>
	</div>
	<?php
}

function linma_brand_run_import() {
	$log   = array();
	$order = 0;

	foreach ( linma_brand_seed() as $b ) {
		$order += 10;

		// Сверяем по названию: адрес записи WordPress составляет сам,
		// и для кириллических названий он получается непредсказуемым.
		$exists = get_posts( array(
			'post_type'   => 'linma_brand',
			'title'       => $b['name'],
			'post_status' => 'any',
			'numberposts' => 1,
		) );

		if ( $exists ) {
			$log[] = array( 'name' => $b['name'], 'status' => 'уже был — пропущен' );
			continue;
		}

		$post_id = wp_insert_post( array(
			'post_type'   => 'linma_brand',
			'post_status' => 'publish',
			'post_title'  => $b['name'],
			'menu_order'  => $order,
		), true );

		if ( is_wp_error( $post_id ) ) {
			$log[] = array( 'name' => $b['name'], 'status' => 'не удалось создать запись' );
			continue;
		}

		update_post_meta( $post_id, '_linma_groups', $b['groups'] );
		update_post_meta( $post_id, '_linma_url', $b['url'] );

		$notes = array();

		if ( $b['file'] ) {
			// Функция объявлена в functions.php — она общая для переносов.
			$logo_id = function_exists( 'linma_sideload_theme_file' )
				? linma_sideload_theme_file( 'assets/img/brands/' . $b['file'] )
				: 0;

			if ( $logo_id ) {
				set_post_thumbnail( $post_id, $logo_id );
			} else {
				$notes[] = 'логотип не найден';
			}
		} else {
			$notes[] = 'логотипа не было';
		}

		$log[] = array(
			'name'   => $b['name'],
			'status' => $notes ? 'создан, но ' . implode( ', ', $notes ) : 'создан с логотипом',
		);
	}

	return $log;
}
