<?php
/**
 * Раздел «Сертификаты» в админке.
 *
 * До этого сертификаты жили в файле assets/js/certificates.js, и чтобы
 * добавить новый, приходилось лезть на хостинг через файловый менеджер.
 * Здесь они становятся обычными записями WordPress: загрузили скан
 * кнопкой, заполнили поля, опубликовали.
 *
 * Что важно знать при правках:
 *   - Заголовок записи — это марка (Daikin, VENTZ). Она же крупная подпись.
 *   - Скан прикладывается как изображение записи. Миниатюру WordPress
 *     делает сам, готовить второй файл не нужно.
 *   - Порядок на странице задаётся полем «Порядок» в блоке «Атрибуты».
 *   - Альбомные документы помечаются галочкой и выводятся отдельной
 *     сеткой под книжными — так же, как было раньше.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ===================================================================
 *  ТИП ЗАПИСИ И РАЗМЕРЫ КАРТИНОК
 * ===================================================================
 */

function linma_cert_register() {
	register_post_type( 'linma_cert', array(
		'labels' => array(
			'name'               => 'Сертификаты',
			'singular_name'      => 'Сертификат',
			'menu_name'          => 'Сертификаты',
			'add_new'            => 'Добавить',
			'add_new_item'       => 'Новый сертификат',
			'edit_item'          => 'Редактирование сертификата',
			'new_item'           => 'Новый сертификат',
			'view_item'          => 'Смотреть сертификат',
			'search_items'       => 'Искать сертификаты',
			'not_found'          => 'Сертификатов пока нет',
			'not_found_in_trash' => 'В корзине пусто',
			'featured_image'     => 'Скан сертификата',
			'set_featured_image' => 'Загрузить скан',
			'remove_featured_image' => 'Убрать скан',
			'use_featured_image' => 'Использовать как скан',
		),
		// Отдельных страниц у сертификатов нет — они показываются только
		// плитками на странице «Дилерские сертификаты».
		'public'             => false,
		'publicly_queryable' => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'menu_position'      => 21,
		'menu_icon'          => 'dashicons-awards',
		'supports'           => array( 'title', 'thumbnail', 'page-attributes' ),
		'has_archive'        => false,
		'rewrite'            => false,
		'can_export'         => true,
	) );

	// Ровно те размеры, что использовались раньше: 1200 px для просмотра
	// и 560 px для плитки. Обрезки нет — пропорции документа сохраняются.
	add_image_size( 'linma-cert', 1200, 1200, false );
	add_image_size( 'linma-cert-thumb', 560, 560, false );
}
add_action( 'init', 'linma_cert_register' );

/**
 * Заголовок поля «Название» понятнее назвать маркой — иначе неочевидно,
 * что туда писать.
 */
function linma_cert_title_placeholder( $text, $post ) {
	if ( $post && 'linma_cert' === $post->post_type ) {
		return 'Марка — например, Daikin';
	}
	return $text;
}
add_filter( 'enter_title_here', 'linma_cert_title_placeholder', 10, 2 );

/**
 * ===================================================================
 *  ПОЛЯ
 * ===================================================================
 */

function linma_cert_meta_box() {
	add_meta_box(
		'linma-cert-fields',
		'Данные сертификата',
		'linma_cert_meta_box_html',
		'linma_cert',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'linma_cert_meta_box' );

function linma_cert_meta_box_html( $post ) {
	wp_nonce_field( 'linma_cert_save', 'linma_cert_nonce' );

	$issuer = get_post_meta( $post->ID, '_linma_issuer', true );
	$type   = get_post_meta( $post->ID, '_linma_type', true );
	$valid  = get_post_meta( $post->ID, '_linma_valid', true );
	$ends   = get_post_meta( $post->ID, '_linma_ends', true );
	$wide   = get_post_meta( $post->ID, '_linma_wide', true );
	$pdf_id = (int) get_post_meta( $post->ID, '_linma_pdf', true );
	$pdf_url = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';

	// Медиатека нужна для кнопки выбора PDF.
	wp_enqueue_media();
	?>
	<style>
		.linma-fields { display: grid; gap: 1.1rem; max-width: 720px; margin: .6rem 0; }
		.linma-fields label { display: block; font-weight: 600; margin-bottom: .3rem; }
		.linma-fields input[type="text"],
		.linma-fields input[type="date"] { width: 100%; }
		.linma-fields .hint { margin: .3rem 0 0; color: #646970; font-size: 12px; }
		.linma-pdf-row { display: flex; gap: .5rem; align-items: center; flex-wrap: wrap; }
		.linma-pdf-name { font-family: monospace; }
	</style>

	<div class="linma-fields">

		<div>
			<label for="linma-type">Тип документа</label>
			<input type="text" id="linma-type" name="linma_type"
			       value="<?php echo esc_attr( $type ); ?>"
			       placeholder="Официальный дилер">
			<p class="hint">Формулировка из самого документа: «Официальный дилер»,
				«Партнёр», «Официальный дистрибьютор». Показывается над маркой.</p>
		</div>

		<div>
			<label for="linma-issuer">Кем выдан</label>
			<input type="text" id="linma-issuer" name="linma_issuer"
			       value="<?php echo esc_attr( $issuer ); ?>"
			       placeholder="ООО «Компания»">
			<p class="hint">Организация, выдавшая документ. Мелкая подпись под маркой.</p>
		</div>

		<div>
			<label for="linma-valid">Срок действия словами</label>
			<input type="text" id="linma-valid" name="linma_valid"
			       value="<?php echo esc_attr( $valid ); ?>"
			       placeholder="до 31 декабря 2027">
			<p class="hint">Как написано в документе. Видно только в окне просмотра.
				Если срок не указан — можно написать «выдан 14 июля 2026».</p>
		</div>

		<div>
			<label for="linma-ends">Дата окончания</label>
			<input type="date" id="linma-ends" name="linma_ends"
			       value="<?php echo esc_attr( $ends ); ?>">
			<p class="hint">Нужна только для того, чтобы сайт сам повесил плашку
				«Срок истёк», когда дата пройдёт. Если срока нет — оставьте пустым.</p>
		</div>

		<div>
			<label>Документ PDF</label>
			<div class="linma-pdf-row">
				<input type="hidden" id="linma-pdf" name="linma_pdf" value="<?php echo esc_attr( $pdf_id ); ?>">
				<button type="button" class="button" id="linma-pdf-pick">Выбрать файл</button>
				<button type="button" class="button-link" id="linma-pdf-clear"
				        <?php echo $pdf_id ? '' : 'style="display:none"'; ?>>убрать</button>
				<span class="linma-pdf-name" id="linma-pdf-name"><?php
					echo $pdf_url ? esc_html( basename( $pdf_url ) ) : '';
				?></span>
			</div>
			<p class="hint">Его скачивают по кнопке в окне просмотра.</p>
		</div>

		<div>
			<label style="font-weight:400">
				<input type="checkbox" name="linma_wide" value="1" <?php checked( $wide, '1' ); ?>>
				Документ альбомной ориентации
			</label>
			<p class="hint">Такие выводятся отдельной сеткой под книжными и получают
				горизонтальную рамку. Для вертикальных галочку не ставьте.</p>
		</div>

	</div>

	<script>
	jQuery(function ($) {
		var frame;
		$('#linma-pdf-pick').on('click', function (e) {
			e.preventDefault();
			if (frame) { frame.open(); return; }
			frame = wp.media({
				title: 'Выберите PDF сертификата',
				button: { text: 'Использовать этот файл' },
				library: { type: 'application/pdf' },
				multiple: false
			});
			frame.on('select', function () {
				var f = frame.state().get('selection').first().toJSON();
				$('#linma-pdf').val(f.id);
				$('#linma-pdf-name').text(f.filename || f.url);
				$('#linma-pdf-clear').show();
			});
			frame.open();
		});
		$('#linma-pdf-clear').on('click', function (e) {
			e.preventDefault();
			$('#linma-pdf').val('');
			$('#linma-pdf-name').text('');
			$(this).hide();
		});
	});
	</script>
	<?php
}

function linma_cert_save( $post_id ) {
	if ( ! isset( $_POST['linma_cert_nonce'] )
		|| ! wp_verify_nonce( sanitize_key( $_POST['linma_cert_nonce'] ), 'linma_cert_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$text = array(
		'_linma_issuer' => 'linma_issuer',
		'_linma_type'   => 'linma_type',
		'_linma_valid'  => 'linma_valid',
	);
	foreach ( $text as $meta => $field ) {
		$value = isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : '';
		update_post_meta( $post_id, $meta, $value );
	}

	// Дата хранится строкой ГГГГ-ММ-ДД — в этом виде её сравнивает и сайт.
	$ends = isset( $_POST['linma_ends'] ) ? sanitize_text_field( wp_unslash( $_POST['linma_ends'] ) ) : '';
	if ( $ends && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $ends ) ) {
		$ends = '';
	}
	update_post_meta( $post_id, '_linma_ends', $ends );

	update_post_meta( $post_id, '_linma_pdf', isset( $_POST['linma_pdf'] ) ? (int) $_POST['linma_pdf'] : 0 );
	update_post_meta( $post_id, '_linma_wide', isset( $_POST['linma_wide'] ) ? '1' : '' );
}
add_action( 'save_post_linma_cert', 'linma_cert_save' );

/**
 * ===================================================================
 *  СПИСОК В АДМИНКЕ
 * ===================================================================
 *
 * Столбцы по умолчанию бесполезны: видно только название и дату. Ставим
 * то, по чему сертификат узнают с первого взгляда, — скан и срок.
 */

function linma_cert_columns( $cols ) {
	return array(
		'cb'           => isset( $cols['cb'] ) ? $cols['cb'] : '',
		'linma_scan'   => 'Скан',
		'title'        => 'Марка',
		'linma_type'   => 'Тип документа',
		'linma_issuer' => 'Кем выдан',
		'linma_ends'   => 'Действует',
		'menu_order'   => 'Порядок',
	);
}
add_filter( 'manage_linma_cert_posts_columns', 'linma_cert_columns' );

function linma_cert_column( $col, $post_id ) {
	switch ( $col ) {
		case 'linma_scan':
			if ( has_post_thumbnail( $post_id ) ) {
				echo get_the_post_thumbnail( $post_id, array( 48, 48 ), array( 'style' => 'width:auto;height:48px;border-radius:3px' ) );
			} else {
				echo '<span style="color:#d63638">нет скана</span>';
			}
			break;

		case 'linma_type':
			echo esc_html( get_post_meta( $post_id, '_linma_type', true ) );
			break;

		case 'linma_issuer':
			echo esc_html( get_post_meta( $post_id, '_linma_issuer', true ) );
			break;

		case 'linma_ends':
			$ends = get_post_meta( $post_id, '_linma_ends', true );
			if ( ! $ends ) {
				echo '<span style="color:#646970">бессрочно</span>';
			} elseif ( strtotime( $ends ) < strtotime( current_time( 'Y-m-d' ) ) ) {
				echo '<strong style="color:#d63638">срок истёк</strong>';
			} else {
				echo esc_html( date_i18n( 'd.m.Y', strtotime( $ends ) ) );
			}
			break;

		case 'menu_order':
			echo (int) get_post_field( 'menu_order', $post_id );
			break;
	}
}
add_action( 'manage_linma_cert_posts_custom_column', 'linma_cert_column', 10, 2 );

function linma_cert_sortable( $cols ) {
	$cols['menu_order'] = 'menu_order';
	$cols['linma_ends'] = 'linma_ends';
	return $cols;
}
add_filter( 'manage_edit-linma_cert_sortable_columns', 'linma_cert_sortable' );

/**
 * По умолчанию WordPress сортирует по дате создания. Нам нужен порядок
 * вывода на сайте, иначе список в админке не совпадает со страницей.
 */
function linma_cert_admin_order( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( 'linma_cert' !== $query->get( 'post_type' ) ) {
		return;
	}
	if ( ! $query->get( 'orderby' ) ) {
		$query->set( 'orderby', 'menu_order title' );
		$query->set( 'order', 'ASC' );
	}
}
add_action( 'pre_get_posts', 'linma_cert_admin_order' );

/**
 * ===================================================================
 *  ДАННЫЕ ДЛЯ САЙТА
 * ===================================================================
 */

/**
 * Собирает сертификаты в том же виде, в каком их раньше отдавал
 * certificates.js, плюс готовые адреса файлов: в WordPress они лежат
 * в медиатеке, а не в папке темы, и по имени их не собрать.
 *
 * Порядок: сначала книжные, следом альбомные — так же, как на странице.
 */
function linma_cert_items() {
	$posts = get_posts( array(
		'post_type'      => 'linma_cert',
		'post_status'    => 'publish',
		'numberposts'    => -1,
		'orderby'        => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
	) );

	$portrait = array();
	$wide     = array();

	foreach ( $posts as $post ) {
		$thumb_id = get_post_thumbnail_id( $post->ID );
		$pdf_id   = (int) get_post_meta( $post->ID, '_linma_pdf', true );

		$item = array(
			'slug'   => $post->post_name,
			'brand'  => $post->post_title,
			'issuer' => (string) get_post_meta( $post->ID, '_linma_issuer', true ),
			'type'   => (string) get_post_meta( $post->ID, '_linma_type', true ),
			'valid'  => (string) get_post_meta( $post->ID, '_linma_valid', true ),
			'ends'   => (string) get_post_meta( $post->ID, '_linma_ends', true ),
			'img'    => $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'linma-cert' ) : '',
			'thumb'  => $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'linma-cert-thumb' ) : '',
			'pdf'    => $pdf_id ? wp_get_attachment_url( $pdf_id ) : '',
		);

		if ( get_post_meta( $post->ID, '_linma_wide', true ) ) {
			$item['wide'] = true;
			$wide[] = $item;
		} else {
			$portrait[] = $item;
		}
	}

	return array_merge( $portrait, $wide );
}

/**
 * Разметка плиток. Повторяет ту, что раньше собирал скрипт в браузере,
 * — иначе развалились бы стили. Отличие одно: теперь она приходит уже
 * готовой в HTML, поэтому сертификаты видят поисковики.
 */
function linma_cert_cards( $items, $wide_wanted ) {
	$today = strtotime( current_time( 'Y-m-d' ) );

	foreach ( $items as $i => $c ) {
		$is_wide = ! empty( $c['wide'] );
		if ( $is_wide !== $wide_wanted ) {
			continue;
		}

		$expired = $c['ends'] && strtotime( $c['ends'] ) < $today;
		?>
		<button type="button" class="card cert-card" data-cert-open="<?php echo (int) $i; ?>"
		        aria-label="Открыть сертификат: <?php echo esc_attr( $c['brand'] ); ?>">
			<div class="cert-sheet<?php echo $is_wide ? ' cert-sheet--wide' : ''; ?>">
				<?php if ( $c['thumb'] ) : ?>
					<img src="<?php echo esc_url( $c['thumb'] ); ?>"
					     alt="Сертификат <?php echo esc_attr( $c['brand'] ); ?>" loading="lazy">
				<?php endif; ?>
				<span class="cert-zoom" aria-hidden="true">
					<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="7" cy="7" r="5" stroke="currentColor" stroke-width="1.6"/><path d="M7 5v4M5 7h4M10.8 10.8 14 14" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
				</span>
			</div>
			<div class="cert-body">
				<span class="cert-type"><?php echo esc_html( $c['type'] ); ?></span>
				<span class="cert-brand"><?php echo esc_html( $c['brand'] ); ?></span>
				<span class="cert-meta"><?php echo esc_html( $c['issuer'] ); ?></span>
				<?php if ( $expired ) : ?>
					<span class="cert-expired">Срок истёк</span>
				<?php endif; ?>
			</div>
		</button>
		<?php
	}
}

/**
 * Отдаёт тот же массив скрипту — на нём держится окно просмотра
 * (листание стрелками, счётчик, ссылка на PDF).
 */
function linma_cert_inline_data( $items ) {
	echo '<script>window.LINMA_CERTIFICATES = '
		. wp_json_encode( $items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES )
		. ';</script>' . "\n";
}
