<?php
/**
 * Тема Linma Electronics.
 *
 * Содержимое страниц лежит в шаблонах темы, а не в админке — так и было
 * задумано при переносе. Правки текста делаются в файлах page-*.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LINMA_VERSION', '1.1.0' );

/**
 * Раздел «Сертификаты» в админке и разовый перенос старых из файлов темы.
 * Когда перенос сделан и проверен, вторую строку можно закомментировать —
 * пункт меню «Перенести из файлов» пропадёт, остальное продолжит работать.
 */
require_once get_template_directory() . '/inc/certificates.php';
require_once get_template_directory() . '/inc/certificates-import.php';
require_once get_template_directory() . '/inc/brands.php';
require_once get_template_directory() . '/inc/brands-import.php';

/**
 * Кладёт файл из папки темы в медиатеку и возвращает его номер.
 * Нужна обоим переносам — сертификатам и брендам.
 *
 * Исходник копируется во временный файл: media_handle_sideload забирает
 * то, что ему дали, и файл темы иначе просто исчез бы.
 */
function linma_sideload_theme_file( $relative_path ) {
	$source = trailingslashit( get_template_directory() ) . ltrim( $relative_path, '/' );
	if ( ! file_exists( $source ) ) {
		return 0;
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$tmp = wp_tempnam( basename( $source ) );
	if ( ! $tmp || ! copy( $source, $tmp ) ) {
		return 0;
	}

	$file = array(
		'name'     => basename( $source ),
		'tmp_name' => $tmp,
	);

	$id = media_handle_sideload( $file, 0 );

	if ( is_wp_error( $id ) ) {
		if ( file_exists( $tmp ) ) {
			wp_delete_file( $tmp );
		}
		return 0;
	}

	return (int) $id;
}

/**
 * Изображения записи. На них держатся сканы сертификатов.
 *
 * Строка обязательна: без неё WordPress не выводит блок «Скан сертификата»
 * в редакторе, даже если тип записи объявил поддержку thumbnail. Раньше
 * теме это было не нужно — картинки нигде не брались из админки.
 */
function linma_setup() {
	add_theme_support( 'post-thumbnails' );
}
add_action( 'after_setup_theme', 'linma_setup' );

/**
 * ===================================================================
 *  ЕДИНСТВЕННОЕ, ЧТО НУЖНО ВПИСАТЬ ВРУЧНУЮ ПОСЛЕ УСТАНОВКИ
 * ===================================================================
 *
 * Номер формы Contact Form 7. Возьмите его в админке:
 * Контакты → Формы → в столбце «Шорткод» будет [contact-form-7 id="123" ...]
 * Нужны только цифры — впишите их между кавычками ниже.
 *
 * Пока строка пустая, на месте формы выводится напоминание.
 */
define( 'LINMA_CF7_ID', '' );

/**
 * Адрес файла в папке assets внутри темы.
 *
 * В статической версии картинки лежали рядом со страницей и путь был
 * простым — «assets/img/…». В WordPress страница открывается по адресу
 * вроде /brands/, а файлы лежат в /wp-content/themes/linma-theme/assets/,
 * поэтому относительный путь ведёт в никуда. Все ссылки на файлы в
 * шаблонах идут через эту функцию.
 */
function linma_asset( $path ) {
	return esc_url( get_template_directory_uri() . '/assets/' . ltrim( $path, '/' ) );
}

/**
 * Выводит форму заявки. $topic — тема обращения: она попадёт в письмо
 * и покажет, с какой страницы пришла заявка.
 */
function linma_form( $topic ) {
	if ( '' === LINMA_CF7_ID ) {
		echo '<div class="card form-card"><p class="form-status is-error">'
			. 'Форма не настроена: впишите номер формы Contact Form 7 в файл functions.php, строка LINMA_CF7_ID.'
			. '</p></div>';
		return;
	}
	echo do_shortcode( sprintf(
		'[contact-form-7 id="%s" html_class="card form-card" topic="%s"]',
		esc_attr( LINMA_CF7_ID ),
		esc_attr( $topic )
	) );
}

/**
 * Стили и скрипты.
 *
 * Файлы данных обязаны загружаться ДО main.js: он читает из них глобальные
 * массивы при старте. Порядок держится на зависимостях, а не на порядке
 * вызовов — WordPress иначе не гарантирует последовательность.
 */
function linma_assets() {
	$dir = get_template_directory_uri();

	// Шрифты лежат на самом сайте, а не подтягиваются с серверов Google:
	// при загрузке со стороны страница успевала отрисоваться системным
	// шрифтом, а потом перекладывалась заново — меню прыгало на 67px.
	// Заодно на сайт не попадают запросы к сторонним сервисам.
	//
	// Файл весит около 290 КБ: начертания первого экрана вшиты в него
	// самой строкой стиля, чтобы запасной шрифт не успевал появиться.
	// Подробности — в шапке самого fonts.css.
	wp_enqueue_style( 'linma-fonts', $dir . '/assets/css/fonts.css', array(), LINMA_VERSION );

	wp_enqueue_style( 'linma-main', $dir . '/assets/css/main.css', array( 'linma-fonts' ), LINMA_VERSION );

	// brands.js больше не подключается: бренды приходят из админки,
	// список печатает linma_brand_inline_data() ниже. Файл оставлен
	// в теме — из него работает статическая версия сайта.
	$deps = array();

	if ( is_front_page() || is_page_template( 'page-projects.php' ) ) {
		wp_enqueue_script( 'linma-map', $dir . '/assets/js/ru-map.js', array(), LINMA_VERSION, false );
		$deps[] = 'linma-map';
	}
	if ( is_page_template( 'page-projects.php' ) ) {
		wp_enqueue_script( 'linma-projects', $dir . '/assets/js/projects.js', array(), LINMA_VERSION, false );
		$deps[] = 'linma-projects';
	}
	// certificates.js больше не подключается: сертификаты приходят из
	// админки, и список для окна просмотра печатает сам шаблон страницы.
	// Файл оставлен в теме — из него работает статическая версия сайта.
	if ( is_page_template( 'page-production.php' ) ) {
		wp_enqueue_script( 'linma-production', $dir . '/assets/js/production.js', array(), LINMA_VERSION, false );
		$deps[] = 'linma-production';
	}

	wp_enqueue_script( 'linma-main', $dir . '/assets/js/main.js', $deps, LINMA_VERSION, true );

	// Скрипт сам собирает адреса картинок сертификатов, объектов, продукции
	// и логотипов брендов. В статической версии он брал их относительно
	// страницы; здесь папка лежит в теме, поэтому адрес передаём явно.
	wp_add_inline_script(
		'linma-main',
		'window.LINMA_ASSETS = ' . wp_json_encode( $dir . '/assets' ) . ';',
		'before'
	);
}
add_action( 'wp_enqueue_scripts', 'linma_assets' );

/**
 * Список брендов для скрипта. Нужен почти везде: бегущая строка идёт
 * на главной, блок «Бренды направления» — на страницах оборудования,
 * сетка с фильтром — на странице брендов. Печатаем в подвале, перед
 * main.js, который его и читает.
 */
add_action( 'wp_footer', 'linma_brand_inline_data', 5 );

/**
 * Иконки сайта. Задаём в теме, а не через «Логотип сайта» в настройках:
 * SVG остаётся основным, PNG — запасным и для домашнего экрана iOS.
 */
function linma_icons() {
	$dir = get_template_directory_uri();
	echo '<link rel="icon" href="' . esc_url( $dir . '/assets/img/linma-logo.svg' ) . '" type="image/svg+xml">' . "\n";
	echo '<link rel="icon" href="' . esc_url( $dir . '/assets/img/favicon-32x32.png' ) . '" sizes="32x32" type="image/png">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( $dir . '/assets/img/favicon-180x180.png' ) . '">' . "\n";
}
add_action( 'wp_head', 'linma_icons', 1 );

/**
 * Разметка организации для поисковых систем — только на главной.
 * Правится вместе с контактами в подвале: расхождение между разметкой
 * и видимым на странице текстом поисковики считают ошибкой.
 */
function linma_schema() {
	if ( ! is_front_page() ) {
		return;
	}
	$data = array(
		'@context'   => 'https://schema.org',
		'@type'      => 'Organization',
		'@id'        => trailingslashit( home_url() ) . '#organization',
		'name'       => 'Linma Electronics',
		'legalName'  => 'Общество с ограниченной ответственностью «ЛИНМА»',
		'alternateName' => 'ООО «ЛИНМА»',
		'url'        => trailingslashit( home_url() ),
		'logo'       => get_template_directory_uri() . '/assets/img/linma-logo.svg',
		'description' => 'Комплексный поставщик систем отопления, вентиляции и кондиционирования с собственным производством комплексов автоматизированного управления.',
		'telephone'  => '+7-495-215-06-52',
		'email'      => 'info@linmatech.ru',
		'taxID'      => '4020006400',
		'address'    => array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => 'пер. Переведеновский, д. 13, стр. 18',
			'addressLocality' => 'Москва',
			'postalCode'      => '105082',
			'addressCountry'  => 'RU',
		),
		'openingHoursSpecification' => array(
			'@type'     => 'OpeningHoursSpecification',
			'dayOfWeek' => array( 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday' ),
			'opens'     => '09:00',
			'closes'    => '18:00',
		),
		'areaServed' => array( '@type' => 'Country', 'name' => 'Россия' ),
	);
	echo '<script type="application/ld+json">'
		. wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES )
		. '</script>' . "\n";
}
add_action( 'wp_head', 'linma_schema', 5 );

/**
 * Мета-теги пишет сама тема, поэтому просим SEO-плагины не добавлять свои.
 * Два canonical или два og:title на странице поисковик считает ошибкой.
 * Если решите вести мета-теги через Yoast или Rank Math — удалите этот
 * блок и уберите соответствующие теги из header.php.
 */
add_filter( 'wpseo_canonical', '__return_false' );
add_filter( 'wpseo_opengraph', '__return_false' );
add_filter( 'rank_math/frontend/canonical', '__return_false' );

/**
 * Лишнее в <head>, что WordPress добавляет по умолчанию.
 */
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );

/**
 * Contact Form 7 присылает свои стили и скрипт на все страницы.
 * Оформление формы задано в main.css, поэтому стили плагина отключаем,
 * а скрипт оставляем — на нём держится отправка без перезагрузки.
 *
 * Важно: вместе со стилями пропадает и то, чем плагин прячет свою
 * служебную разметку — рамку <fieldset> со скрытыми полями и блок
 * сообщений. Эти правила повторены в main.css, раздел «Разметка
 * Contact Form 7». Если будете что-то менять — менять надо в паре.
 */
add_filter( 'wpcf7_load_css', '__return_false' );

/**
 * Разметка формы у нас своя и уже разбита на блоки. WordPress же по
 * привычке расставляет в ней <p> и <br> на каждом переводе строки:
 * между подписью поля и самим полем появляется лишний отступ, а в
 * строке согласия — перенос перед галочкой. Отключаем.
 */
add_filter( 'wpcf7_autop_or_not', '__return_false' );
